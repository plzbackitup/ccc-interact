# web-python-prompt

Uses Skulpt to run Python code in an interactive online shell.

Demo: running `testmain.html`

<img src="/pictures/example_of_python_code.PNG" width="400">
 
<img src="/pictures/input_demo.gif" width="400">
 
<img src="/pictures/resize_demo.gif" width="611">
